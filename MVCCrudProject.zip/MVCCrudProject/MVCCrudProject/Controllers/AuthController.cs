﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVCCrudProject.Data;
using MVCCrudProject.Models;

namespace MVCCrudProject.Controllers
{
    public class AuthController : Controller
    {
        private readonly ApplicationDbContext db;
        public AuthController (ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public async Task<IActionResult> SignUp()
        {
            return View();
        }
        [HttpPost]
        public async Task<IActionResult> SignUp(Auth a)
        {
            Auth registerusers = new Auth();
            registerusers.Username = a.Username;
            registerusers.Password = a.Password;
            registerusers.Email = a.Email; ;
            await db.Auths.AddAsync(registerusers);
            await db.SaveChangesAsync();
            return RedirectToAction("Login", "Auth");
        }

        [HttpGet]
        public async Task<IActionResult> Login()
        {
            if (HttpContext.Session.GetString("SessionName") != null)
            {
                return RedirectToAction("Login", "Auth");
            }
            else
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Login(Auth Login)
        {
            var checkuser = await db.Auths.Where(user => user.Email == Login.Email && user.Password == Login.Password).FirstOrDefaultAsync();
            if (checkuser != null)
            {
                HttpContext.Session.SetString("SessionName", checkuser.Username);
                return RedirectToAction("Add", "CRUD");
            }
            else
            {
                ViewBag.Message = "Login is Failed...";
            }
                return View();
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
