﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using MVCCrudProject.Data;
using MVCCrudProject.Models;

namespace MVCCrudProject.Controllers
{
    public class CRUDController : Controller
    {
        public readonly ApplicationDbContext db;

        public CRUDController(ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public IActionResult Add()
        {
            if (HttpContext.Session.GetString("SessionName") != null)
            {
                ViewBag.message = HttpContext.Session.GetString("SessionName").ToString() ;
            }
            else
            { 
                return RedirectToAction("Login", "Auth");
            }
                return View();
        }

        [HttpPost]
        public async Task<IActionResult> Add(User u)
        {
                var users = new User
                {
                    Name = u.Name,
                    Email = u.Email,
                    Contact = u.Contact,
                    Password = u.Password
                };
                await db.user.AddAsync(u);
                await db.SaveChangesAsync();
                return RedirectToAction("Add", "CRUD");
        }

        [HttpGet]
        public async Task<IActionResult> ListUser()
        {
            if (HttpContext.Session.GetString("SessionName") != null)
            {
                var users = await db.user.ToListAsync();
                return View(users);
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }
        }

        [HttpGet]
        public async Task<IActionResult> Edit(Guid id)
        {
            if (HttpContext.Session.GetString("SessionName") != null)
            {
                ViewBag.message = HttpContext.Session.GetString("SessionName");

                var user = await db.user.FindAsync(id);
                return View(user);
            }
            else
            {
                return RedirectToAction("Login", "Auth");
            }

        }

        [HttpPost]
        public async Task<IActionResult> Edit(User u)
        {
            var user = await db.user.FindAsync(u.Id);

            if (user != null)
            {
                user.Name = u.Name;
                user.Email = u.Email;
                user.Contact = u.Contact;
                user.Password = u.Password;

                await db.SaveChangesAsync();
            }
            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> Delete(User ud)
        {
            var user = await db.user.AsNoTracking().FirstOrDefaultAsync(u => u.Id == ud.Id);
            if (user != null)
            {
                db.user.Remove(ud);
                await db.SaveChangesAsync();
            }
            return RedirectToAction("ListUser", "CRUD");
        }
    }
}
