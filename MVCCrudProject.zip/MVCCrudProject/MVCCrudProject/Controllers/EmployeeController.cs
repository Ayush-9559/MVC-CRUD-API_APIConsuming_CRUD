﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.DotNet.Scaffolding.Shared.Messaging;
using Microsoft.EntityFrameworkCore;
using MVCCrudProject.Data;
using MVCCrudProject.Models;

namespace MVCCrudProject.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly ApplicationDbContext db;
        
        public EmployeeController(ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public async Task<IActionResult> AddEmp()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> AddEmp(Employee e)
        {
            if (e == null)
            {
                return Ok("Enter All Details");
            }
            var Emp = new Employee
            {
                Name = e.Name,
                Email = e.Email,
                ContactNo = e.ContactNo,
                Gender = e.Gender,
                Locality = e.Locality,
                Department = e.Department
            };
            await db.emp.AddAsync(e);
            await db.SaveChangesAsync();
            return View("AddEmp");
        }

        [HttpGet]
        public async Task<IActionResult> EmpList()
        {
            var emp = await db.emp.ToListAsync();
            return View(emp);
        }

        [HttpGet]
        public async Task<IActionResult> EditEmp(int id)
        {
            var employees = await db.emp.FindAsync(id);
            return View(employees);
        }

        [HttpPost]
        public async Task<IActionResult> EditEmp(Employee emp)
        {
            var user = await db.emp.FindAsync(emp.Id);

            if (user != null)
            {
                user.Name = emp.Name;
                user.Email = emp.Email;
                user.ContactNo = emp.ContactNo;
                user.Gender = emp.Gender;
                user.Locality = emp.Locality;
                user.Department = emp.Department;

                await db.SaveChangesAsync();
            }
            return View(user);
        }


        public IActionResult DeleteEmp(int id)
        {
            var data = db.emp.Find(id);
            if(data == null)
            {
                return NotFound();
            }
            else
            {
                db.emp.Remove(data);
                db.SaveChanges();
                TempData["msg"]= "Delete Sucessfully";
                return RedirectToAction("EmpList");
            }
        }

    }
}

