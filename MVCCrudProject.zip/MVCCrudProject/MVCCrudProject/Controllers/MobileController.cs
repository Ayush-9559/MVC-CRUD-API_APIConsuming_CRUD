﻿using Microsoft.AspNetCore.Mvc;
using MVCCrudProject.Data;
using MVCCrudProject.Models;

namespace MVCCrudProject.Controllers
{
    public class MobileController : Controller
    {
        private readonly ApplicationDbContext db;

        public MobileController(ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public IActionResult Add()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Add(MobileModel mdm)
        {
            if (mdm == null)
            {
                return Ok("Enter All Details");
            }
            var mobiles = new MobileModel
            {
                MName = mdm.MName,
                MDescription = mdm.MDescription,
                MProcessor = mdm.MProcessor,
                MPrice = mdm.MPrice
            };
            db.mobile.Add(mobiles);
            db.SaveChanges();
            return View("Add");
        }

        [HttpGet]
        public IActionResult Index()
        {
            var mobiledata = db.mobile.ToList();
            return View(mobiledata);
        }

        [HttpGet]
        public IActionResult EditDetails(int id)
        {
            var mobiledetails = db.mobile.Find(id);
            return View(mobiledetails);
        }

        [HttpPost]
        public IActionResult EditDetails(MobileModel mdm)
        {
            return View();
        }

        
        public IActionResult DeleteDetails(int id)
        {
            var mobiledetails = db.mobile.Find(id);
            db.mobile.Remove(mobiledetails);
            db.SaveChanges();
            return RedirectToAction("Index", "Mobile");
        }
    }
}
