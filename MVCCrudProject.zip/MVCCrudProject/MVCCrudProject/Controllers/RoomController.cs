﻿using Microsoft.AspNetCore.Mvc;
using MVCCrudProject.Data;
using MVCCrudProject.Models;

namespace MVCCrudProject.Controllers
{
    public class RoomController : Controller
    {
        private readonly ApplicationDbContext db;
        public RoomController(ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public IActionResult AddRoom()
        {
            return View();
        }
        [HttpPost]
        public IActionResult AddRoom(Room rm)
        {
            var addroom = db.Rooms.Add(rm);
            db.SaveChanges();
            return View(addroom);
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
