﻿using Microsoft.EntityFrameworkCore;
using MVCCrudProject.Models;

namespace MVCCrudProject.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

        public DbSet<User> user { get; set; }
        public DbSet<Employee> emp {  get; set; }
        public DbSet<MobileModel> mobile { get; set; }

        public DbSet<Auth> Auths { get; set; }
        public DbSet<Hotel> Hotels { get; set; }
        public DbSet<Room> Rooms { get; set; }
    }
}
