﻿namespace MVCCrudProject.Models
{
    public class Employee
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
        public long ContactNo { get; set; }
        public string Gender { get; set; }
        public string Locality { get; set; }
        public string Department { get; set; }

    }
}
