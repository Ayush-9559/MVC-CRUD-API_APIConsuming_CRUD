﻿namespace MVCCrudProject.Models
{
    public class Hotel
    {
        public int Id { get; set; }
        public string PersonName { get; set; }
        public long ContactNo { get; set; }
        public string Proof { get; set; }
        public int RoomNo { get; set; }
        public string RoomType { get; set; }
        public string Food { get; set; }
        public DateTime DateTime { get; set; }
    }
}
