﻿namespace MVCCrudProject.Models
{
    public class MobileModel
    {
        public int Id { get; set; }
        public required string MName { get; set; }
        public required string MDescription { get; set; }
        public required string MProcessor { get; set; }
        public required decimal MPrice { get; set; }
    }
}
