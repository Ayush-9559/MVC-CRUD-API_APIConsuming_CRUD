﻿namespace MVCCrudProject.Models
{
    public class Room
    {
        public int Id { get; set; }
        public int RoomNo { get; set; }
        public string RoomType { get; set; }
    }
}
