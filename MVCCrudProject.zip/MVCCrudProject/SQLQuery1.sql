select * from mobile;

drop table emp;
drop table [user];

Truncate table mobile;
